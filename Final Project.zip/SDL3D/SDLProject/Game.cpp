//
//  Game.cpp
//  SDLProject
//
//  Created by Hanyi Wang on 2021/8/5.
//  Copyright © 2021 ctg. All rights reserved.
//

#include "Game.h"

#define OBJECT_COUNT 1
#define ENEMY_COUNT 3
#define KEY_COUNT 3
void Game:: Initialize(){
    state.nextScene = -1;
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(2, 0.75f, 0);
    state.player->acceleration = glm::vec3(0, 0, 0);
    state.player->speed = 1.0f;
    state.player->rotation = glm::vec3(0,0,0);
    
    state.object = new Entity[OBJECT_COUNT];
    
    state.object[0].textureID = Util:: LoadTexture("floor.jpg");
    Mesh *cubeMesh = new Mesh();
    cubeMesh->LoadOBJ("cube.obj",20);
    state.object[0].mesh = cubeMesh;
    state.object[0].position = glm::vec3(0,-0.25f,0);
    state.object[0].acceleration = glm::vec3(0,0,0);
    state.object[0].rotation = glm::vec3(0,0,0);
    state.object[0].entityType = FLOOR;
    state.object[0].scale = glm::vec3(20,0.5f,20);
    
    state.enemies = new Entity[ENEMY_COUNT];
    GLuint enemyTextureID = Util::LoadTexture("zombie.png");
    for (int i = 0; i < ENEMY_COUNT; i++) {
        state.enemies[i].billboard = true;
        state.enemies[i].textureID = enemyTextureID;
        state.enemies[i].position = glm::vec3(rand() % 20 - 10, 0.5f, rand() % 20 - 10);
        state.enemies[i].rotation = glm::vec3(0, 0, 0);
        state.enemies[i].acceleration = glm::vec3(0, 0, 0);
        state.enemies[i].entityType = ENEMY;
    }
    state.Keys = new Entity[KEY_COUNT];
    GLuint keyTextureID = Util::LoadTexture("key.png");
    for(int i = 0; i < KEY_COUNT; i++){
        state.Keys[i].billboard = true;
        state.Keys[i].textureID = keyTextureID;
        state.Keys[i].position = glm::vec3(rand() % 20 - 10, 0.5f, rand() % 20 - 10);
        state.Keys[i].rotation = glm::vec3(0,0,0);
        state.Keys[i].acceleration = glm::vec3(0,0,0);
        state.Keys[i].entityType = KEY;
        state.Keys[i].billboard = true;
    }
}

void Game::Update(float deltaTime) {
    state.player->Update(deltaTime,state.player,state.enemies,state.Keys,state.object,OBJECT_COUNT, ENEMY_COUNT,KEY_COUNT);
    for(int i = 0; i< OBJECT_COUNT; i++){
        state.object[i].Update(deltaTime,state.player,state.enemies,state.Keys,state.object,OBJECT_COUNT,ENEMY_COUNT,KEY_COUNT);
    }
    for(int i = 0; i< ENEMY_COUNT; i++){
        state.enemies[i].Update(deltaTime,state.player,state.enemies,state.Keys,state.object,OBJECT_COUNT,ENEMY_COUNT,KEY_COUNT);
    }
    for(int i = 0; i< KEY_COUNT; i++){
        if(state.Keys[i].isActive)
            state.Keys[i].Update(deltaTime,state.player,state.enemies,state.Keys,state.object,OBJECT_COUNT,ENEMY_COUNT,KEY_COUNT);
    }
    
}

void Game::Render(ShaderProgram *program){
    for(int i = 0; i < OBJECT_COUNT; i++){
        state.object[i].Render(program);
    }
    for(int i = 0; i < ENEMY_COUNT; i++){
        state.enemies[i].Render(program);
    }
    for(int i = 0; i < KEY_COUNT; i++){
        if(state.Keys[i].isActive)
            state.Keys[i].Render(program);
    }
}
void Game::Reset()
{
    Game::Initialize();
}
