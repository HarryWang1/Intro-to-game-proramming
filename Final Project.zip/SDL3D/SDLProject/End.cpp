//
//  End.cpp
//  Fix
//
//  Created by Hanyi Wang on 2021/7/26.
//

#include "End.h"
#include <stdio.h>
#include "Scene.h"



void End::Initialize() {
    state.isMenu = true;
}
void End::Update(float deltaTime) {
    state.nextScene = -1;
}
void End::Render(ShaderProgram *program) {
    GLuint font;
    font = Util::LoadTexture("font.png");
    Util::DrawText(program, font, "You Win!", 0.5f, -0.25f, glm::vec3(-2.0f, 1.0f, 0.0f));
}
void End::Reset(){
    End::Initialize();
}
