//
//  Game.hpp
//  SDLProject
//
//  Created by Hanyi Wang on 2021/8/5.
//  Copyright © 2021 ctg. All rights reserved.
//

#include "Scene.h"
class Game : public Scene {
public:
    void Initialize() override;
    void Update(float deltaTime) override;
    void Render(ShaderProgram *program) override;
    void Reset() override;
};
