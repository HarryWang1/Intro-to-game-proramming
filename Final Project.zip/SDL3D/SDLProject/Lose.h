//
//  Lose.hpp
//  Fix
//
//  Created by Hanyi Wang on 2021/7/26.
//

#include "Scene.h"
class Lose : public Scene {
public:
    void Initialize() override;
    void Update(float deltaTime) override;
    void Render(ShaderProgram *program) override;
    void Reset() override;
};
