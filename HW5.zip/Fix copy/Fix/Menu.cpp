//
//  Menu.cpp
//  Fix
//
//  Created by Hanyi Wang on 2021/7/22.
//

#include "Menu.h"
#include <stdio.h>
#include "Scene.h"



void Menu::Initialize() {
    state.isMenu = true;
}
void Menu::Update(float deltaTime) {
    state.nextScene = -1;
}
void Menu::Render(ShaderProgram *program) {
    GLuint font;
    font = Util::LoadTexture("font.png");
    Util::DrawText(program, font, "Game Start!", 0.5f, -0.25f, glm::vec3(-2.0f, 1.0f, 0.0f));
}
void Menu::Reset(){
    Menu::Initialize();
}
