//
//  Level1.cpp
//  Fix
//
//  Created by Hanyi Wang on 2021/7/22.
//

#include "Level1.h"
#include <stdio.h>
#include "Scene.h"

#define LEVEL1_WIDTH 14
#define LEVEL1_HEIGHT 8
#define Level1_ENEMY_COUNT 1
unsigned int level1_data[] = {
    2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2
};

void Level1::Initialize() {
    state.nextScene = -1;
    state.isMenu = false;
    GLuint mapTextureID = Util::LoadTexture("simple_tileset.png");
    state.map = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level1_data, mapTextureID, 1.0f, 4, 1);
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(5,0,0);
    state.player->movement = glm::vec3(0);
    state.player->speed = 2.0f;
    state.player->acceleration = glm::vec3(0,-1.0f,0);//gravity
    state.player -> isHero = true;

    
    state.player->textureID = Util::LoadTexture("betty.png");
    
    state.player->animRight = new int[4] {3, 7, 11, 15};
    state.player->animLeft = new int[4] {1, 5, 9, 13};
    state.player->animUp = new int[4] {2, 6, 10, 14};
    state.player->animDown = new int[4] {0, 4, 8, 12};
    state.player->height = 0.8f;

    state.player->animIndices = state.player->animRight;
    state.player->animFrames = 4;
    state.player->animIndex = 0;
    state.player->animTime = 0;
    state.player->animCols = 4;
    state.player->animRows = 4;
    
    
    state.enemys = new Entity[Level1_ENEMY_COUNT];
    GLuint enemyTextureID = Util::LoadTexture("character_zombie_cheer0.png");
    state.enemys[0].textureID = enemyTextureID;
    state.enemys[0].position = glm::vec3(8,-1,0);
    state.enemys[0].speed = 1;
    state.enemys[0].acceleration = glm::vec3(0,-1.0f,0);//gravity
    state.enemys[0].movement = glm::vec3(0);
    
    state.enemys[0].entityType = ENEMY;
    state.enemys[0].aiType = WAITANDGO;
    state.enemys[0].aiState = IDLE;

    
}
void Level1::Update(float deltaTime) {
    state.player->Update(deltaTime, state.enemys, state.map,Level1_ENEMY_COUNT);
    for(int i = 0; i<Level1_ENEMY_COUNT;i++){
        state.enemys[i].Update(deltaTime,state.player, state.map,Level1_ENEMY_COUNT);
    }
    if(state.player->position.x >= 12){
        state.nextScene = 2;
    }
}
void Level1::Render(ShaderProgram *program) {
    state.map->Render(program);
    state.player->Render(program);
    for(int i = 0; i<Level1_ENEMY_COUNT;i++){
        state.enemys[i].Render(program);
    }
}

void Level1::Reset()
{
    Level1::Initialize();
}
