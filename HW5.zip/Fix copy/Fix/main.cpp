#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_mixer.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#include "Entity.h"
#include "Map.h"
#include "Util.h"

#include "Scene.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "Menu.h"
#include "End.h"
#include "Lose.h"


Scene *currentScene;
Scene *sceneList[6];
Mix_Music *music;
Mix_Chunk *jump_sound;



void SwitchToScene(Scene *scene) {
    currentScene = scene;
    currentScene->Initialize();
}


SDL_Window* displayWindow;
bool gameIsRunning = true;
GLuint font;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

bool sceneDone = false;
int current_live = 3;
bool killed = false;

void Initialize() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    displayWindow = SDL_CreateWindow("PLATFORMER!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
    
#ifdef _WINDOWS
    glewInit();
#endif
    
    glViewport(0, 0, 640, 480);
    
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    
    viewMatrix = glm::mat4(1.0f);
    modelMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);
    
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    
    glUseProgram(program.programID);
    
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    glEnable(GL_BLEND);

    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    font = Util::LoadTexture("font.png");
    sceneList[0] = new Menu();
    sceneList[1] = new Level1();
    sceneList[2] = new Level2();
    sceneList[3] = new Level3();
    sceneList[4] = new End();
    sceneList[5] = new Lose();

    SwitchToScene(sceneList[0]);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    music = Mix_LoadMUS("arcade_carnival.wav");
    Mix_PlayMusic(music, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    jump_sound = Mix_LoadWAV("jumpland.wav");
}

void ProcessInput() {
    if(!currentScene->state.isMenu)
        currentScene->state.player->movement = glm::vec3(0);
    
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
            case SDL_WINDOWEVENT_CLOSE:
                gameIsRunning = false;
                break;
                
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_LEFT:
                        // Move the player left
                        break;
                        
                    case SDLK_RIGHT:
                        // Move the player right
                        break;
                        
                    case SDLK_SPACE:
                        // Some sort of action
                        break;
                    case SDLK_RETURN:
                        
                        break;
                }
                break; // SDL_KEYDOWN
        }
    }
    
    const Uint8 *keys = SDL_GetKeyboardState(NULL);

    if (keys[SDL_SCANCODE_LEFT]) {
        if(!currentScene->state.isMenu){

            currentScene->state.player->movement.x = -1.0f;
                //state.player->acceleration.x -= 2.0f;
            currentScene->state.player->animIndices = currentScene->state.player->animLeft;
        }
        
    }
    else if (keys[SDL_SCANCODE_RIGHT]) {
        if(!currentScene->state.isMenu){

            currentScene->state.player->movement.x = 1.0f;
            //state.player->acceleration.x += 2.0f;
            currentScene->state.player->animIndices = currentScene->state.player->animRight;
        }
        
    }
    
    else if (keys[SDL_SCANCODE_SPACE]){
        if(!currentScene->state.isMenu){
            if(currentScene->state.player->collidedBottom){
                //state.player->position.y = 0.05f;
                currentScene->state.player->velocity.y = 1.8f;
                currentScene->state.player->collidedBottom = false;
                currentScene->state.player->animIndices = currentScene->state.player->animRight;
                Mix_PlayChannel(-1, jump_sound, 0);
                
            }
        }
    }
    else if(keys[SDL_SCANCODE_RETURN]){
        std::cout << "RETURN" << std::endl;
        if(currentScene->state.isMenu){
            sceneDone = true;
        }
    }
   
    if(!currentScene->state.isMenu){
        if (glm::length(currentScene->state.player->movement) > 1.0f) {
            currentScene->state.player->movement = glm::normalize(currentScene->state.player->movement);
        }
    }

}

//float lastTicks = 0.0f;

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update() {
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP) {
        accumulator = deltaTime;
        return;
    }
    while (deltaTime >= FIXED_TIMESTEP) {
    // Update. Notice it's FIXED_TIMESTEP. Not deltaTime
        
        currentScene->Update(FIXED_TIMESTEP);
        deltaTime -= FIXED_TIMESTEP;
    }
    accumulator = deltaTime;
    
    viewMatrix = glm::mat4(1.0f);
    if(!currentScene->state.isMenu){
        if (currentScene->state.player->position.x > 5) {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(-currentScene->state.player->position.x, 3.75, 0));
        }
        else {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(-5, 3.75, 0));
        }
    }

}


void Render() {
    program.SetViewMatrix(viewMatrix);
    glClear(GL_COLOR_BUFFER_BIT);

    currentScene->Render(&program);
    
    SDL_GL_SwapWindow(displayWindow);
}


void Shutdown() {
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    Initialize();

    while (gameIsRunning) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
                gameIsRunning = false;
            }
        }
        
        ProcessInput();
        // 3 levels
        if(!currentScene->state.isMenu){
            if(currentScene->state.player->killed) {
                currentScene->Reset();
                current_live -= 1;
            }
            if(current_live>0)
                Update();
        }
        // menu page
        else if(currentScene->state.isMenu)
            Update();
        
        if(currentScene->state.nextScene >= 0){
            
            SwitchToScene(sceneList[currentScene->state.nextScene]);
            
        }
        if(currentScene->state.isMenu && sceneDone){
            SwitchToScene(sceneList[1]);
            sceneDone = false;
        }
        if (current_live==0){
            SwitchToScene(sceneList[5]);
        }
        Render();
    }
    
    Shutdown();
    return 0;
}
